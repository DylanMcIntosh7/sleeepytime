package com.example.sleeeeeeeeepytiiiiiiime;


public class Alarm {
    private int hours;
    private int minutes;

    public Alarm(int h, int m)
    {
        hours = h;
        minutes = m;
    }

    public Alarm()
    {
        hours = 0;
        minutes = 0;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public boolean isEmpty()
    {
        if(hours == 0 && minutes == 0)
            return true;
        return false;
    }
}
