package com.example.sleeeeeeeeepytiiiiiiime;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AlarmPage extends AppCompatActivity {
    private EditText etTime;
    private EditText Minutes;
    private TextView savedAlarm;
    private DatabaseReference reff;
    private FirebaseDatabase database;
    private String name, pass, id;
    private int hoursSaved, minutesSaved;
    private Bundle info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarms);

        database = FirebaseDatabase.getInstance();
        reff = database.getReference("user" );
        Intent intent = getIntent();
        info = intent.getExtras();
        name = info.getString("user");
        pass = info.getString("pass");
        id = info.getString("id");
        hoursSaved = info.getInt("hours");
        minutesSaved = info.getInt("minutes");
        savedAlarm = (TextView)findViewById(R.id.txtAlarm);
        savedAlarm.setText("Saved Alarm: " + hoursSaved + "h " + minutesSaved + "m");
     //   get alarm from bundle


    }

    public void saveAlarm(View view)
    {
        int hours;
        int minutes;
        etTime = (EditText)findViewById(R.id.etTime);
        Minutes = (EditText)findViewById(R.id.Minutes);
       if(etTime.getText().toString().length() > 0 && Minutes.getText().toString().length() > 0) {

           hours = Integer.parseInt(etTime.getText().toString());
           minutes = Integer.parseInt(Minutes.getText().toString());
           if(hours > 0 || minutes > 0) {
               User u = new User(name, pass, id);
               Alarm a = new Alarm(hours, minutes);
               u.saveAlarm(a);
               info.remove("hours");
               info.putInt("hours", hours);
               info.remove("minutes");
               info.putInt("minutes", minutes);
               hoursSaved = hours;
               minutesSaved = minutes;
               //Change bundle alarm
               reff.child(id).setValue(u);
               savedAlarm.setText("Saved Alarm: " + hours + "h " + minutes + "m");
               Toast.makeText(this, "Alarm successfully saved", Toast.LENGTH_LONG).show();
           }
       }
       else
           Toast.makeText( this, "Error: please fill out all fields", Toast.LENGTH_LONG ).show();
    }

    public void deleteAlarm(View view)
    {

        if(hoursSaved != 0 && minutesSaved != 0) {


            User u = new User(name, pass, id);
            hoursSaved = 0;
            minutesSaved = 0;

            info.remove("hours");
            info.putInt("hours", hoursSaved);
            info.remove("minutes");
            info.putInt("minutes", minutesSaved);


            reff.child(id).setValue(u);
            savedAlarm.setText("Saved Alarm: ");
            Toast.makeText( this, "Successfully deleted", Toast.LENGTH_LONG ).show();
        }
        else
            Toast.makeText( this, "No alarm to delete", Toast.LENGTH_LONG ).show();
    }

    public void setAlarm(View view) {
        int hours, minutes;

        if (etTime.getText().toString().length() > 0 && Minutes.getText().toString().length() > 0) {

            hours = Integer.parseInt(etTime.getText().toString());
            minutes = Integer.parseInt(Minutes.getText().toString());
            if (hours > 0 || minutes > 0) {
                hours = Integer.parseInt(etTime.getText().toString()) * 3600000;
                minutes = Integer.parseInt(Minutes.getText().toString()) * 60000;
                int time = hours + minutes;
                Intent i = new Intent(AlarmPage.this, AlarmTrigger.class);
                PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 0, i, 0);
                AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
                am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + time, pi);
                Toast.makeText( this, "Alarm successfully set for " + hours/3600000 + " hours and " + minutes/60000 + " minutes", Toast.LENGTH_LONG ).show();
            }
            Toast.makeText( this, "Invalid inputs", Toast.LENGTH_LONG ).show();
        }
        Toast.makeText( this, "Please fill out all fields", Toast.LENGTH_LONG ).show();
    }

    public void setSaved(View view)
    {
        if(hoursSaved > 0 || minutesSaved > 0)
        {
            int time = hoursSaved * 3600000 + minutesSaved * 60000;
            Intent i = new Intent(AlarmPage.this, AlarmTrigger.class);
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 0, i, 0);
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + time, pi);
            Toast.makeText(this, "Alarm successfully set for " + hoursSaved + " hours and " + minutesSaved + " minutes", Toast.LENGTH_LONG).show();
        }
        Toast.makeText(this, "No alarm saved", Toast.LENGTH_LONG).show();
    }

    public void goToSettings(View view)
    {

        Intent intent = new Intent(view.getContext(), Settings.class);
        intent.putExtras(info);
        startActivity(intent);
    }
}
