package com.example.sleeeeeeeeepytiiiiiiime;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Settings extends AppCompatActivity {
    private EditText txtEditUser;
    private EditText txtEditPass;
    private DatabaseReference reff;
    private FirebaseDatabase database;
    private String name, pass, id;
    private Alarm al;
    private Bundle info;
    private int hours, minutes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        database = FirebaseDatabase.getInstance();
        reff = database.getReference("user" );
        Intent intent = getIntent();
        info = intent.getExtras();
        name = info.getString("user");
        pass = info.getString("pass");
        id = info.getString("id");
        hours = info.getInt("hours");
        minutes = info.getInt("minutes");

        //Save alarm from bundle


    }

    public void changeUser(View view)
    {
        String newName;
        txtEditUser = (EditText)findViewById(R.id.txtEditUser);
        if(txtEditUser.getText().toString().length() > 0) {

            newName = txtEditUser.getText().toString();
            User u = new User(newName, pass, id);
            Alarm al = new Alarm(hours, minutes);
            u.saveAlarm(al);
            //System.out.println(user.getId());
            name = newName;
            info.remove("user");
            info.putString("user", name);
            reff.child(id).setValue(u);
            Toast.makeText( this, "Your username has been updated", Toast.LENGTH_LONG ).show();
        }
        else
            Toast.makeText( this, "Error: no username input", Toast.LENGTH_LONG ).show();
    }

    public void changePass(View view)
    {
        String newPass;
        txtEditPass = (EditText)findViewById(R.id.txtEditPass);
        if(txtEditPass.getText().toString().length() > 0) {

            newPass = txtEditPass.getText().toString();
            User u = new User(name, newPass, id);
            Alarm al = new Alarm(hours, minutes);
            u.saveAlarm(al);
            //System.out.println(user.getId());
            pass = newPass;
            info.remove("pass");
            info.putString("pass", pass);
            reff.child(id).setValue(u);
            Toast.makeText( this, "Your password has been updated", Toast.LENGTH_LONG ).show();
        }
        else
            Toast.makeText( this, "Error: no password input", Toast.LENGTH_LONG ).show();
    }

    public void goToAlarms(View view)
    {
        Intent intent = new Intent(view.getContext(), AlarmPage.class);
        intent.putExtras(info);
        startActivity(intent);
    }
}