package com.example.sleepytime;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.sleeeeeeeeepytiiiiiiime.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DataRetrieve extends AppCompatActivity {
    TextView a, b;
    Button btn;
    DatabaseReference reff;

  /*  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a = (TextView)findViewById(R.id.Name);
        b = (TextView)findViewById(R.id.Alarm1); //Figure out how alarms will be displayed and what the object stores
        btn = (Button)findViewById(R.id.showAlarms); //Make it so it retrieves data when the page is opened and then have edit buttons to retrieve alarm objects and modify them or delete them


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reff = FirebaseDatabase.getInstance().getReference().child("User").child("1");
                reff.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot ) {
                        String name = dataSnapshot.child("name").getValue().toString();

                    }
                });
            }
        });
    }

   */
}