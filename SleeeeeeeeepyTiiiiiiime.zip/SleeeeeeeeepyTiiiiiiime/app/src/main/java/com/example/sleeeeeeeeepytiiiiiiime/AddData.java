package com.example.sleeeeeeeeepytiiiiiiime;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddData extends AppCompatActivity {
    EditText txtName, txtPass;
    //  Button btnCreate;
    private DatabaseReference reff;
    private FirebaseDatabase database;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = FirebaseDatabase.getInstance();
        reff = database.getReference("user");
    }

    public void addUser(View view) {
        txtName = (EditText) findViewById(R.id.txtName);
        String name = txtName.getText().toString();
        txtPass = (EditText) findViewById(R.id.txtPass);
        String password = txtPass.getText().toString();

        if (name.length() > 0 && password.length() > 0)
        {
            String key = reff.push().getKey();
            User user = new User();
            user.setUsername(name);
            user.setPassword(password);
            reff.child(key).setValue(user);
            Toast.makeText(AddData.this, "Account created successfully! Please login", Toast.LENGTH_LONG).show();
        }

    }
}
